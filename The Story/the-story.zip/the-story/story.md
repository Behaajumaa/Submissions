# SAVE YIVA


### INTRODUCTION
---------
"Save Yiva" is an interactive game story designed by Dreamer team. It is an entertainment interactive game that is determined by the player in order to experience unique story based on the player interactions.

------
### STORYLINE
-------
Once upon a time, there was a beautiful forest that was located ** named Yiva. It was home to all kinds of species and living organisms, until "Kohona clan" showed up. They conquered Yiva and rained destruction on the forest, wiping out most of the trees and wildlife. However, Yiva still has hope to recover. Two native survivers named "Bella" and "Fred" didnt give up on retaining the forest. They have one mission, protect Yiva from Kohona clan.

------






